#ifndef ENUM_H
#define ENUM_H

#include<iostream>
 enum class AutomobileType{
        PRIVATE,
        TRANSPORT
 };

#endif // ENUM_H
