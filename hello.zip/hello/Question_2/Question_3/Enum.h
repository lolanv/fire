#ifndef ENUM_H
#define ENUM_H

#include<iostream>
enum class CarType { 
COMMUTE, 
COMMERCIAL, 
TRANSPORT };

#endif // ENUM_H
