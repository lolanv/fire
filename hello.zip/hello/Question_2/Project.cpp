// Project.cpp
#include "Project.h"

Project::Project(std::string name, float budget) : _project_name(name), _project_budget(budget) {}